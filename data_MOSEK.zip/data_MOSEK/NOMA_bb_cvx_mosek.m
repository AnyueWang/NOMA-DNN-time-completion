%NOMA + time completion 
%solved by Mosek 9.0
%date: 5/23/2020
%University of Luxembourg
%email: anyue.wang@uni.lu

clear all; clear; clc;

tic;
user=8;
T=10;%number of time slots
Y=zeros(1,T);
X=zeros(user,T);
L=2;%maximal number of users at each time slot
M=10;%confine the value of y
N=10;%confine the value of R
sigma=5*10^(-15);%-173dbm/Hz*BW(1MHz)
P_max=2;%transmit power:33dBm
Tx=20;%dBi

num_ite=6000;%the number of sample
H_sample=zeros(user,num_ite);
R_sample=zeros(user*T,num_ite);
x_sample=zeros(user*T,num_ite);
y_sample=zeros(1,num_ite);
d_sample=zeros(user,num_ite);
pre_sample=zeros(1,num_ite);

i_ite=1;

% for i_b=1:9
while(i_ite<=num_ite)
    
    D=3+5*rand(1,user)';%demands
    d_sample(:,i_ite)=D;
    
    i_ite
    
    distance=(50+250*rand(user,1))/1000;
    PL=46.33+(44.9-6.55*log10(4.5))*log10(distance)+33.9*log10(2000)-((1.1*log10(2000)-0.7)*1.7-1.56*log10(2000)+0.8)-13.82*log10(45)+3;
    H=(sort(10.^((Tx-PL)/10),'descend'));%COST-231-HATA

    A_H=zeros(user,T);
    for t=1:T
        for k=1:user
            if k==1
                A_H(k,t)=sigma*(1/H(k));
            else
                A_H(k,t)=sigma*(1/H(k)-1/H(k-1));
            end
        end
    end
    E_H=zeros(user,user);
    for ii=1:user
        for jj=ii:user
            if ii<=jj
                E_H(ii,jj)=1;
            end
        end
    end
    
    %variables:y:1
    %          x:user*T
    %          R:user*T
    %          r(exp(R)):user*T

    A_R=zeros(0);
    for u=1:user%R>=D
        A_R1=zeros(1+3*user,T);
        A_R1(1+user+u,:)=1;
        A_R1=reshape(A_R1',1,(1+3*user)*T);
        A_R=[A_R;A_R1];
    end
    for t=1:T%x<=L
        A_R2=zeros(1+3*user,T);
        A_R2(2:1+user,t)=1;
        A_R2=reshape(A_R2',1,(1+3*user)*T);
        A_R=[A_R;A_R2];
    end
    for t=1:T%x<=My
        A_R3=zeros(1+3*user,T);
        A_R3(2:1+user,t)=1;
        A_R3(1,t)=-M;
        A_R3=reshape(A_R3',1,(1+3*user)*T);
        A_R=[A_R;A_R3];
    end
    for t=1:T%r>=exp sum R
        A_H1=zeros(user,T);
        A_H1(:,t)=A_H(:,t);
        A_R4=[zeros(1+2*user,T);A_H1];
        A_R4=reshape(A_R4',1,(1+3*user)*T);
        A_R=[A_R;A_R4];
    end
    for t=1:T%R<=N*x
        for u=1:user
            A_R5=zeros(1+3*user,T);
            A_R5(u+1,t)=1;
            A_R5(u+user+1,t)=-1/N;
            A_R5=reshape(A_R5',1,(1+3*user)*T);
            A_R=[A_R;A_R5];
        end
    end

    variables=[ones(1,T);%y
               ones(user,T);%x
               zeros(user,T);%R
               zeros(user,T)];%r
    variables=reshape(variables,1,(1+3*user)*T);

    %call Mosek 9.0
    clear prob;
    [r,res]=mosekopt('symbcon');

    prob.c=[ones(1,T) zeros(1,3*user*T)];%r;%obj function
    prob.a=A_R;%linear constraints
    prob.blc=[D' zeros(1,T) -inf*ones(1,T) zeros(1,T) zeros(1,user*T)];
    prob.buc=[inf*ones(1,user) L*ones(1,T) zeros(1,T) (P_max+sigma/H(user))*ones(1,T) inf*ones(1,user*T)];
    prob.blx=zeros(1,(1+user*3)*T);
    prob.bux=inf*ones(1,(1+user*3)*T);
    prob.ints.sub=1:(1+user)*T;%integer variables

    % exponential cones
    E_H1=zeros(user*T);
    for t=1:T
        E_H1(t:T:end,t:T:end)=E_H;
    end
    exp_m=zeros(user*T*3,(1+3*user)*T);
    exp_m(1:3:end,(1+2*user)*T+1:end)=eye(user*T);
    exp_m(3:3:end,(1+user)*T+1:(1+2*user)*T)=E_H1;
    fE=exp_m;
    gE=repmat([0 1 0],1,user*T);

    prob.f=sparse(fE);
    prob.g=gE;
    prob.cones=repmat([res.symbcon.MSK_CT_PEXP 3],1,user*T);

%     [r res]=mosekopt('minimize',prob,params);
    [r res]=mosekopt('minimize',prob);
    opt_y=res.sol.int.xx(1:T);
    opt_x=res.sol.int.xx(T+1:T*(user+1))>0.01;
    matrix_x=reshape(opt_x,T,user)';
    opt_R=res.sol.int.xx(T*(user+1)+1:T*(2*user+1));
    opt_R(find(opt_R<0.01))=0;
    matrix_R=reshape(opt_R,T,user)';
    if res.sol.int.prosta~="PRIMAL_FEASIBLE"
        continue;
    end
    
    x_test=reshape(opt_x,T,user)';    
    
    H_sample(:,i_ite)=H;
    x_sample(:,i_ite)=opt_x;
    R_sample(:,i_ite)=opt_R;
    y_sample(i_ite)=sum(opt_y);
    
    i_ite=i_ite+1;

end

toc




